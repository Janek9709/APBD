﻿using KolosProbny2.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KolosProbny2.Services
{
    public class SqlServerApiDbService : IApiDbService
    {
        private readonly s18313Context _database;

        public SqlServerApiDbService(s18313Context database)
        {
            _database = database;
        }

        public IEnumerable<Object> GetAllZamowienie()
        {
            var resp = _database
                .Klient
                .Join(_database.Zamowienie, klient => klient.IdKlient, zamow => zamow.KlientIdKlient, (klient, zamow) => new { klient, zamow })
                .Join(_database.ZamowienieWyrobCukierniczy, p => p.zamow.IdZamowienia, f => f.IdZamowienia, (p, f) => new { p, f })
                .Join(_database.WyrobCukierniczy, pp => pp.f.IdWyrobuCukierniczego, ff => ff.IdWyrobuCukierniczego, (pp, ff) => new { pp, ff })
                .Select(e => new { Nazwisko = e.pp.p.klient.Nazwisko, Danie = e.ff.Nazwa })
                .ToList();

            return resp;
        }

        public IEnumerable<Object> GetZmowienieNazwisko(string nazwisko)
        {
            var client = _database.Klient.Where(e => e.Nazwisko == nazwisko).Select(e => e.IdKlient).First();
            
            var resp = _database
                .Zamowienie
                .Join(_database.ZamowienieWyrobCukierniczy, p => p.IdZamowienia, f => f.IdZamowienia, (p, f) => new { p, f })
                .Join(_database.WyrobCukierniczy, pp => pp.f.IdWyrobuCukierniczego, ff => ff.IdWyrobuCukierniczego, (pp, ff) => new { pp, ff })
                .Where(e => e.pp.p.KlientIdKlient == client)
                //.Select()
                .ToList();

            return resp;
        }
    }
}
